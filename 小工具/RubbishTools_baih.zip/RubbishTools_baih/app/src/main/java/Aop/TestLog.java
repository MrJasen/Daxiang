package Aop;

import android.util.Log;

/**
 * Created by Administrator on 2016/4/27 0027.
 */
public class TestLog {

    public static void Log(String log){

        Log.e("baih","这个是调用方法插进"+log+"CPUtime:"+android.os.Process.getElapsedCpuTime());
    }
}
