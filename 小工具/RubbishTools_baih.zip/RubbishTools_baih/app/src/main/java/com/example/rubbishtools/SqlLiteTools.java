package com.example.rubbishtools;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Created 复制指定路径下的文件到sd卡
 */
public class SqlLiteTools {

    private final String DATABASE_PATH = android.os.Environment.getExternalStorageDirectory().getAbsolutePath() + "/rubbish";  //需要复制数据库的路径
    private final String DATABASE_FILENAME = "RubbishFiles.db";     //定义复制后的DB文件文件名
    RubbishRecover rubbishRec = new RubbishRecover();
    DateConfig date=new DateConfig();
    private Context context;
    String dateBaseFileName = DATABASE_PATH + "/" + DATABASE_FILENAME;     //DB文件全路径


    public SqlLiteTools(Context context) {
        this.context = context;

    }

    //将raw下的数据源文件复制到/sdcard/rubbish下，名为RubbishFiles.db
    public void CopyDateBase() {

        File file = new File(DATABASE_PATH);
        if (!file.exists()) {
            file.mkdir();
        } else {
            Log.e("baih", "SDcard路径已存在");
        }
        //File file1 = new File(dateBaseFileName);
            try {
                InputStream in = this.context.getResources().openRawResource(R.raw.rabbishfiles);
                FileOutputStream fos = new FileOutputStream(dateBaseFileName);
                byte[] buffer = new byte[8192 * 100];
                int count = 0;
                Log.i("ReleaseDataBaseActivity", "count:" + count);
                //把数据写入SD卡目录下
                while ((count = in.read(buffer)) > 0) {
                    fos.write(buffer, 0, count);
                }
                fos.flush();
                fos.close();
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
    }

    public void DeleteDateBase(){
        File file1=new File(dateBaseFileName);
        if (file1.exists()){
            Log.e("baih","删除老数据库目录");
            file1.delete();
        }

    }


    //获取复制到sdcard下的数据源文件，并返回文件供openOrCreateDatabase使用
    public File getDatebase() {
        //获取DB文件路径
        String dbPath=dateBaseFileName;
        File dbFile = new File(dbPath);
        return dbFile;
    }


    //打开数据源文件，并返回，供调用系统API查询
    //每次触发都会产生，so解决办法是放到onCreated里面，使其创建就会产生
    public SQLiteDatabase openOrCreateDatabase() {
        //SQLiteDatabase result = SQLiteDatabase.openOrCreateDatabase(getDatebase(), null);
        SQLiteDatabase result = date.getdatebase();
        return result;
    }

    public void querySelect(String Sql) {
        //public void querySelect(String Type) {
        //空文件夹查询
        //SqlLiteYu dbHelper = new SqlLiteYu(SQLiteActivity.this,"stu_db",null,1);
        //得到一个可写的数据库
        //SQLiteDatabase db =SqlLiteYu.getReadableDatabase();
        //参数1：表名
        //参数2：要想显示的列
        //参数3：where子句
        //参数4：where子句对应的条件值
        //参数5：分组方式
        //参数6：having条件
        //参数7：排序方式

        Cursor cursor = openOrCreateDatabase().rawQuery(Sql, null);
        cursor.moveToFirst();//避免数据获取不全
        Log.e("baih", cursor.getCount() + "条数据");
        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String type = cursor.getString(1);
            String path = cursor.getString(2);
            String filename = cursor.getString(3);
            String size = cursor.getString(4);
            //製作数据文件
            if (type.equals("空文件夹")) {
                rubbishRec.rubbishmakeNull(path, filename);
            } else {
                rubbishRec.rubbishmake(path, filename, size,1);
            }
        }
    }


    //安装测试用APK
  /*  public void installApk(){
        try {
            String apkName=DATABASE_PATH+"/"+"baidumap.apk";
            InputStream in=this.context.getResources().openRawResource(R.raw.baidumap);
            FileOutputStream fi=new FileOutputStream(apkName);
            byte[] buffer = new byte[8192 * 100];
            int count = 0;
            Log.i("ReleaseDataBaseActivity", "count:" + count);
            //把APK写入SD卡目录下
            while ((count = in.read(buffer)) > 0) {
                fi.write(buffer, 0, count);
            }
            fi.flush();
            fi.close();
            in.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(Uri.fromFile(new File(DATABASE_PATH+"/"+"baidumap.apk")),"application/vnd.android.package-archive");
        this.context.startActivity(intent);
    }*/
};



