package com.example.rubbishtools;

import android.database.sqlite.SQLiteDatabase;

import java.sql.ResultSet;
import java.util.ArrayList;

public class DateConfig {

    public static Boolean isConnected = false;
    public static Boolean isGeted = false;
    public static ResultSet rubbishResult = null;
    public static String rubbishPath;
    public static String rubbishName;
    public static String rubbishType;
    public static String rubbishSize;
    public static String result;
    public static ArrayList<String> cachelist = new ArrayList<String>();
    public static SQLiteDatabase Sqldate;
    public static String Log;

    public void setLog(String log){
        DateConfig.Log=log;
    }

    public String getLog(){
        return  Log;
    }

    public void setdatebase(SQLiteDatabase date){
        DateConfig.Sqldate=date;
    }

    public SQLiteDatabase getdatebase(){
        return Sqldate;
    }

    public void setList(ArrayList<String> list) {
        DateConfig.cachelist = list;
    }

    public ArrayList<String> getList() {
        return cachelist;
    }

    public void setPath(String path) {
        DateConfig.rubbishPath = path;
    }

    public String getPath() {
        return rubbishPath;
    }

    public void setName(String name) {
        DateConfig.rubbishName = name;
    }

    public String getName() {
        return rubbishName;
    }

    public void setSize(String size) {
        DateConfig.rubbishSize = size;
    }

    public String getSize() {
        return rubbishSize;
    }

    public void setIsConnected(Boolean isconnect) {
        DateConfig.isConnected = isconnect;
    }

    public Boolean getIsConnected() {
        return isConnected;
    }

    public void setRubbishResult(ResultSet date) {
        DateConfig.rubbishResult = date;
    }

    public ResultSet getRubbishResult() {
        return rubbishResult;
    }

    public void setIsGeted(Boolean isget) {
        DateConfig.isGeted = isget;
    }

    public Boolean getIsGeted() {
        return isGeted;
    }

}
