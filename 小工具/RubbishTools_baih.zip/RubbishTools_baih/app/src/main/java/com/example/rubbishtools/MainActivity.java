package com.example.rubbishtools;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends Activity {

    RubbishRecover rubbishRec = new RubbishRecover();
    SqlLiteTools dbTools = new SqlLiteTools(this);
    DateConfig date=new DateConfig();
    TextView tx1;
    Random ra = new Random();
    static int sjs;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn1 = (Button) findViewById(R.id.all);
        btn1.setOnClickListener(makeAll);
        Button btn2 = (Button) findViewById(R.id.bigfiles);
        btn2.setOnClickListener(makeBigfile);
        Button btn3 = (Button) findViewById(R.id.residual);
        btn3.setOnClickListener(makeRes);
        Button btn4 = (Button) findViewById(R.id.audiofiles);
        btn4.setOnClickListener(makeAudio);
        Button btn5 = (Button) findViewById(R.id.Downloadfiles);
        btn5.setOnClickListener(makeDownload);
        Button btn6 = (Button) findViewById(R.id.apkfiles);
        btn6.setOnClickListener(makeApk);
        Button btn7 = (Button) findViewById(R.id.guanggao);
        btn7.setOnClickListener(makeGuanggao);
        Button btn8 = (Button) findViewById(R.id.nullmulu);
        btn8.setOnClickListener(makeNullmulu);
        Button btn9 = (Button) findViewById(R.id.sys);
        btn9.setOnClickListener(makeSys);
        tx1=(TextView)findViewById(R.id.textView);
        dbTools.DeleteDateBase();
        dbTools.CopyDateBase();
        date.setdatebase(SQLiteDatabase.openOrCreateDatabase(dbTools.getDatebase(), null));
        //dbTools.installApk();
    }

    private class MakeTask extends AsyncTask<String ,String, String> {
        //onPreExecute方法用于在执行后台任务前做一些UI操作
        @Override
        protected void onPreExecute() {
            Log.i("baih", "onPreExecute() called");
        }

        //doInBackground方法内部执行后台任务,不可在此方法内修改UI，用于执行耗时操作，防止ANR
        @Override
        protected String doInBackground(String... sql) {
            //sql[1]为0是单项垃圾文件制作
            if(sql[1].equals("0")){
                Cursor cursor = dbTools.openOrCreateDatabase().rawQuery(sql[0], null);
                cursor.moveToFirst();//避免数据获取不全
                Log.e("baih", cursor.getCount() + "条数据");
                while (cursor.moveToNext()) {
                    int id = cursor.getInt(0);
                    String type = cursor.getString(1);
                    String path = cursor.getString(2);
                    String filename = cursor.getString(3);
                    String size = cursor.getString(4);
                    //製作数据文件
                    if (type.equals("空文件夹")) {
                        rubbishRec.rubbishmakeNull(path, filename);
                        publishProgress(filename);//在后台任务中调用publishProgress方法进行UI更新
                    } else {
                        rubbishRec.rubbishmake(path, filename, size,1);
                        publishProgress(filename);
                    }
                }
            }
            else{
                //sql[1]为1是制作系统缓存
                if(sql[1].equals("1")){
                    rubbishRec.getSystem(Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/data");
                    for (String path : date.getList()) {
                        //获取随机数sjs
                        sjs = ra.nextInt(10) + 1;
                        //通过随机数制作系统缓存垃圾文件
                        for (int j = 0; j < sjs; j++) {
                            String filen="baihuatest"+System.currentTimeMillis();
                            rubbishRec.rubbishmake(path,filen, "2000",0);
                            publishProgress(filen);
                        }
                    }
                }else{
                    //sql[1]为其他则是一键制作
                    Cursor cursor = dbTools.openOrCreateDatabase().rawQuery(sql[0], null);
                    cursor.moveToFirst();//避免数据获取不全
                    Log.e("baih", cursor.getCount() + "条数据");
                    rubbishRec.getSystem(Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/data");
                    for (String path : date.getList()) {
                        //获取随机数sjs
                        sjs = ra.nextInt(10) + 1;
                        //通过随机数制作系统缓存垃圾文件
                        for (int j = 0; j < sjs; j++) {
                            String filen="baihuatest"+System.currentTimeMillis();
                            rubbishRec.rubbishmake(path,filen, "2000",0);
                            publishProgress(filen);
                        }
                    }
                    while (cursor.moveToNext()) {
                        int id = cursor.getInt(0);
                        String type = cursor.getString(1);
                        String path = cursor.getString(2);
                        String filename = cursor.getString(3);
                        String size = cursor.getString(4);
                        //製作数据文件
                        if (type.equals("空文件夹")) {
                            rubbishRec.rubbishmakeNull(path, filename);
                            publishProgress(filename);
                        } else {
                            rubbishRec.rubbishmake(path, filename, size,1);
                            publishProgress(filename);
                        }
                    }
                }
            }


            return null;
        }

        //onProgressUpdate方法用于更新进度信息
        @Override
        protected void onProgressUpdate(String... progresses) {
           super.onProgressUpdate(progresses);
            tx1.setText("正在制作"+progresses[0]);
        }

        //onPostExecute方法用于在执行完后台任务后更新UI,显示结果
        @Override
        protected void onPostExecute(String result) {
            Toast.makeText(getApplicationContext(),"制作完成",Toast.LENGTH_LONG).show();
            tx1.setText("");
        }

        //onCancelled方法用于在取消执行中的任务时更改UI
        @Override
        protected void onCancelled() {

        }
    }

    //制作空文件夹//no change
    public OnClickListener makeNullmulu = new OnClickListener() {

        @Override
        public void onClick(View v) {
            // TODO Auto-generated method stub

            String Sql="select * from files where type='空文件夹'";
            MakeTask mTask=new MakeTask();
            mTask.execute(Sql,"0");
        }
    };

    //制作广告文件
    public OnClickListener makeGuanggao = new OnClickListener() {

        @Override
        public void onClick(View v) {
            // TODO Auto-generated method stub
            String Sql="select * from files where type='广告文件'";
            MakeTask mTask=new MakeTask();
            mTask.execute(Sql,"0");
        }
    };

    //制作安装包文件
    public OnClickListener makeApk = new OnClickListener() {

        @Override
        public void onClick(View v) {
            // TODO Auto-generated method stub
            String Sql="select * from files where type='安装包'";
            MakeTask mTask=new MakeTask();
            mTask.execute(Sql,"0");
        }
    };

    //制作下载文件
    public OnClickListener makeDownload = new OnClickListener() {

        @Override
        public void onClick(View v) {
            // TODO Auto-generated method stub
            String Sql="select * from files where type='下载文件'";
            MakeTask mTask=new MakeTask();
            mTask.execute(Sql,"0");
        }
    };

    //制作音频
    public OnClickListener makeAudio = new OnClickListener() {

        @Override
        public void onClick(View v) {
            // TODO Auto-generated method stub
            String Sql="select * from files where type='音频'";
            MakeTask mTask=new MakeTask();
            mTask.execute(Sql,"0");

        }
    };

    //制作卸载残留
    public OnClickListener makeRes = new OnClickListener() {

        @Override
        public void onClick(View v) {
            // TODO Auto-generated method stub
            String Sql="select * from files where type='卸载残留'";
            MakeTask mTask=new MakeTask();
            mTask.execute(Sql,"0");
        }
    };

    //制作大文件
    public OnClickListener makeBigfile = new OnClickListener() {

        @Override
        public void onClick(View v) {
            // TODO Auto-generated method stub
            String Sql="select * from files where type='大文件'";
            MakeTask mTask=new MakeTask();
            mTask.execute(Sql,"0");
        }
    };

    //制作系统缓存
    public OnClickListener makeSys = new OnClickListener() {

        @Override
        public void onClick(View v) {
            // TODO Auto-generated method stub
            MakeTask mTask=new MakeTask();
            mTask.execute("","1");
        }


    };

    //一键制作按钮点击事件
    public OnClickListener makeAll = new OnClickListener() {

        @Override
        public void onClick(View v) {
            // TODO Auto-generated method stub
            MakeTask mTask=new MakeTask();
            mTask.execute("select * from files","2");
        }
    };
}


