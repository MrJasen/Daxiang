package com.example.rubbishtools;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Random;

public class RubbishRecover {

    DateConfig datecfg = new DateConfig();
    ArrayList<String> cachefilelist = new ArrayList<String>();
    static String dbfilepath;
    Random ra = new Random();
    static int sjs;


    //垃圾文件制作方法
    public void rubbishmake(String filespath, String filesname, String filessize,int type) {
        if (type==0){
            dbfilepath=filespath;
        }else {
            dbfilepath = Environment.getExternalStorageDirectory().getAbsolutePath() + filespath;
        }
        try {
            File path=new File(dbfilepath);
            if(!path.exists()){
                Runtime.getRuntime().exec("mkdir -p " + dbfilepath);
            }else{
               // Log.e("baih",dbfilepath+"不需要制作");
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        try {
            File file=new File(dbfilepath + "/" + filesname);
            if(!file.exists()){
                //Log.e("baih", dbfilepath + "/" + filesname);
                Runtime.getRuntime().exec("dd if=/dev/zero of=" + dbfilepath + "/" + filesname + " bs=1024 count=" + filessize);
            }else{
                //Log.e("baih",dbfilepath + "/" + filesname+"不需要制作");
            }
            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            //Log.e("baih", "制作特征文件成功");
        } catch (IOException e) {
            // TODO Auto-generated catch block
            //Log.e("baih", "制作特征文件失败");
            e.printStackTrace();
        }
    }

    //制作空文件夹的方法
    public void rubbishmakeNull(String filespath, String filesname) {
        String dbfilepathNULL = Environment.getExternalStorageDirectory().getAbsolutePath() + filespath;
        try {
            Runtime.getRuntime().exec("mkdir -p " + dbfilepathNULL + "/" + filesname);
            //Log.e("baih", "制作空文件夹成功");
        } catch (IOException e) {
            // TODO Auto-generated catch block
            //Log.e("baih", "制作空文件夹失败");
            e.printStackTrace();
        }
    }

    //制作系统文件夹的路径
    public void rubbishmakeSys() {
        getSystem(Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/data");
        for (String path : datecfg.getList()) {
            //获取随机数sjs
            sjs = ra.nextInt(10) + 1;
            //通过随机数制作系统缓存垃圾文件
            for (int j = 0; j < sjs; j++) {
                rubbishmake(path, "baihtest_" + System.currentTimeMillis(), "2000",0);
            }
        }
    }

    //系统缓存文件夹遍历
    public void getSystem(String path) {
        File l=new File(path);
        File[] allFiles=l.listFiles();
            for (File f : allFiles) {
                if (f.isDirectory()) {
                    File file = f;
                    File[] androidDateFiles = new File(path + "/" + file.getName()).listFiles();
                    for (File cacheFile : androidDateFiles) {
                        if (cacheFile.getName().equals("cache")) {
                            File file1 = cacheFile;
                            String cachePath = file1.getAbsolutePath();
                            cachefilelist.add(cachePath);
                        }
                    }
                }
            }
            datecfg.setList(cachefilelist);

    }

}



