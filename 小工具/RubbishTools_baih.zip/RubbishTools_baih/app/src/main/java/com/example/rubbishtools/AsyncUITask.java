package com.example.rubbishtools;


import android.util.Log;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Pointcut;

/*@Aspect
public class AsyncUITask {
    @Pointcut("execution(* com.example.rubbishtools.MainActivity.*(..))")
    public void logForActivity(){

    }

    @After("logForActivity()")
    public void log(JoinPoint joinPoint){
        Log.e("baih","我曹，我插进来了"+joinPoint);
    }
}




  /*  public class AsyncUITask extends AsyncTask<String, String, String> {
    RubbishRecover rubbishRec = new RubbishRecover();
    SqlLiteTools dbTools = new SqlLiteTools();
    DateConfig date = new DateConfig();
    TextView tx1;
    Random ra = new Random();
    static int sjs;

    @Override
    protected String doInBackground(String... sql) {
        //sql[1]为0是单项垃圾文件制作
        if (sql[1].equals("0")) {
            Cursor cursor = dbTools.openOrCreateDatabase().rawQuery(sql[0], null);
            cursor.moveToFirst();//避免数据获取不全
            Log.e("baih", cursor.getCount() + "条数据");
            while (cursor.moveToNext()) {
                int id = cursor.getInt(0);
                String type = cursor.getString(1);
                String path = cursor.getString(2);
                String filename = cursor.getString(3);
                String size = cursor.getString(4);
                //製作数据文件
                if (type.equals("空文件夹")) {
                    rubbishRec.rubbishmakeNull(path, filename);
                    publishProgress(filename);//在后台任务中调用publishProgress方法进行UI更新
                } else {
                    rubbishRec.rubbishmake(path, filename, size, 1);
                    publishProgress(filename);
                }
            }
        } else {
            //sql[1]为1是制作系统缓存
            if (sql[1].equals("1")) {
                rubbishRec.getSystem(Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/data");
                for (String path : date.getList()) {
                    //获取随机数sjs
                    sjs = ra.nextInt(10) + 1;
                    //通过随机数制作系统缓存垃圾文件
                    for (int j = 0; j < sjs; j++) {
                        String filen = "baihuatest" + System.currentTimeMillis();
                        rubbishRec.rubbishmake(path, filen, "2000", 0);
                        publishProgress(filen);
                    }
                }
            } else {
                //sql[1]为其他则是一键制作
                Cursor cursor = dbTools.openOrCreateDatabase().rawQuery(sql[0], null);
                cursor.moveToFirst();//避免数据获取不全
                Log.e("baih", cursor.getCount() + "条数据");
                rubbishRec.getSystem(Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/data");
                for (String path : date.getList()) {
                    //获取随机数sjs
                    sjs = ra.nextInt(10) + 1;
                    //通过随机数制作系统缓存垃圾文件
                    for (int j = 0; j < sjs; j++) {
                        String filen = "baihuatest" + System.currentTimeMillis();
                        rubbishRec.rubbishmake(path, filen, "2000", 0);
                        publishProgress(filen);
                    }
                }
                while (cursor.moveToNext()) {
                    int id = cursor.getInt(0);
                    String type = cursor.getString(1);
                    String path = cursor.getString(2);
                    String filename = cursor.getString(3);
                    String size = cursor.getString(4);
                    //製作数据文件
                    if (type.equals("空文件夹")) {
                        rubbishRec.rubbishmakeNull(path, filename);
                        publishProgress(filename);
                    } else {
                        rubbishRec.rubbishmake(path, filename, size, 1);
                        publishProgress(filename);
                    }
                }
            }
        }


        return null;
    }
}*/
