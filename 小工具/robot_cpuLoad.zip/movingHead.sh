#!/system/bin

if [ -f /data/local/tmp/busybox ];then
	bb=/data/local/tmp/busybox
else
	echo "no /data/local/tmp/busybox"
	exit
fi

log(){
echo `echo $EPOCHREALTIME|$bb awk -F. '{printf strftime("%F %T",$1+8*3600)"."substr($2,1,3)}'` "$*"
}

CPU(){
if [ "${cpuTime}a" != "a" ];then
	cpuTime=`$bb awk '$1=="cpu"{print $2,$3,$4,$5,$6,$7,$8}' /proc/stat`
	$bb sleep 1
fi
cpuUsed=`$bb awk -v cpu="$cpuTime" 'BEGIN{split(cpu,D," ")}{if($1=="cpu")print int(100-($5-D[4])*100/($2-D[1]+$3-D[2]+$4-D[3]+$5-D[4]+$6-D[5]+$7-D[6]+$8-D[7]))}' /proc/stat`
cpuTime=`$bb awk '$1=="cpu"{print $2,$3,$4,$5,$6,$7,$8}' /proc/stat`
}

ICanCtrlServiceImpl(){
if [ -f /data/local/tmp/position.log ];then
	$bb rm /data/local/tmp/position.log
fi

logcat -v threadtime -s ICanCtrlServiceImpl -T 60| $bb awk -v F=/data/local/tmp/position.log '$0~/CanPtzProperties/{ \
	gsub(/=|'\'', /," ",$0); \
	split($0,tmp,"propType "); \
	for(i in tmp){ \
		if(i>1){ \
			split(tmp[i],D," "); \
			if(D[1]==2){ \
				P[D[3]]=D[5]; \
				S[D[3]]=D[7] \
			} \
		} \
	}; \
	if(P[4]!=a||P[5]!=b){ \
		print $1,$2,P[4]+0,P[5]+0,S[4]+0,S[5]+0 >F; \
		a=P[4]; \
		b=P[5] \
	} \
}'
}

resetP(){
local w=0
local P=`cat /data/local/tmp/position.log`
if [ ! -z "$P" ];then
	local x=`echo $p|$bb awk '{print 0-$3}'`
	local y=`echo $p|$bb awk '{print 24-$3}'`
	if [ $x -gt 0 ];then
		cmd canctrlservice ptzrelposctrl 4 $x 125
		local w=1
	elif [ $x -lt 0 ];then
		cmd canctrlservice ptzrelposctrl 4 $x -125
		local w=1
	fi
	if [ $x -ne 0 ];then
		cmd canctrlservice ptzrelposctrl 5 $y
		local w=1
	fi
	if [ $w -eq 1 ];then
		log "P=$P"
		log "move x=$x y=$y"
		$bb usleep 1500000
	fi
fi
}

# main
ICanCtrlServiceImpl &
logPId=$!
log "logPId=$logPId"

if [ -f /data/local/tmp/stop ];then
	$bb rm /data/local/tmp/stop
fi

pids=`$bb ps|$bb awk '$4=="/data/local/tmp/busybox"&&$5=="bc"{r=" "$1}END{print r}'`
if [ ! -z $pids ];then
	kill $pids
fi
while true;do
	CPU
	if [ $cpuUsed -lt $1 ];then
		#计算圆周率到小数点后一万位
		echo "scale=10000; 4*a(1)" | $bb bc -l 1>/dev/null 2>&1 &
	fi
	log "CPU=$cpuUsed bc threads="`$bb ps|$bb awk '$4=="/data/local/tmp/busybox"&&$5=="bc"{i+=1}END{print i+0}'`
	resetP
	cmd canctrlservice ptzrelposctrl 4 77 125
	cmd canctrlservice ptzrelposctrl 5 10
	$bb usleep 1500000
	cmd canctrlservice ptzrelposctrl 4 -77 -125
	cmd canctrlservice ptzrelposctrl 5 -10
	$bb usleep 1500000
	cmd canctrlservice ptzrelposctrl 4 -90 -125
	cmd canctrlservice ptzrelposctrl 5 -10
	$bb usleep 1500000
	cmd canctrlservice ptzrelposctrl 4 90 125
	cmd canctrlservice ptzrelposctrl 5 10
	if [ -f /data/local/tmp/stop ];then
		log "Found /data/local/tmp/stop, break"
		kill $((logPId -1)) $logPId`$bb ps|$bb awk '$4=="/data/local/tmp/busybox"&&$5=="bc"{r=" "$1}END{print r}'`
		break
	fi
done
