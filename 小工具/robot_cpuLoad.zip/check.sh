logcat -v threadtime -s ICanCtrlServiceImpl -T 60| /data/local/tmp/busybox awk '$0~/CanPtzProperties/{ \
	gsub(/=|'\'', /," ",$0); \
	split($0,tmp,"propType "); \
	for(i in tmp){ \
		if(i>1){ \
			split(tmp[i],D," "); \
			if(D[1]==2){ \
				P[D[3]]=D[5]; \
				S[D[3]]=D[7] \
			} \
		} \
	}; \
	if(P[4]!=a||P[5]!=b){ \
		print $1,$2,P[4]+0,P[5]+0,S[4]+0,S[5]+0; \
		a=P[4]; \
		b=P[5] \
	} \
}'

#俯仰 0,35 +向下
#默认 0 24
#水平77 -180 +向左
#水平速度最大125 